﻿using System.Diagnostics;
using System.Reflection.Metadata;
using System.Text;

string abc = "ABCDEFGHIJK";
Console.WriteLine(InverterString(abc));


static string InverterString(string stSequencia)
{
    if (string.IsNullOrEmpty(stSequencia) || stSequencia.Length == 0) return string.Empty;

    StringBuilder stRetorno = new StringBuilder();
    for (int i = stSequencia.Length - 1; i >= 0; i--)
    {
        stRetorno.Append(stSequencia[i]);
    }
    return stRetorno.ToString();
}
