using System.Text.Json;
using Teste03;

public class Program
{
    public static void Main()
    {
        string stringJson = File.ReadAllText("json.json");
        List<DTOJson> dados = JsonSerializer.Deserialize<List<DTOJson>>(stringJson);

        if (dados != null)
        {
            decimal menorValor = dados.Min(x => x.Valor);
            List<DTOJson> listaOrdenada = dados.Where(x => x.Valor > 0).ToList().OrderBy(x => x.Valor).ToList();
            DTOJson diaMenorValor = listaOrdenada.First();
            DTOJson diaMaiorValor = listaOrdenada.Last();
            decimal mediaDiariaDiario = listaOrdenada.Average(x => x.Valor);
            List<DTOJson> listaDiasComValorAcimaMediaMensal = listaOrdenada.Where(x => x.Valor > mediaDiariaDiario).ToList();

            Console.WriteLine($"Dia com menor faturamento: Dia: {diaMenorValor.Dia} - Valor: {diaMenorValor.Valor}");
            Console.WriteLine($"Dia com maior faturamento: Dia: {diaMaiorValor.Dia} - Valor: {diaMaiorValor.Valor}");
            Console.WriteLine("");
            Console.WriteLine($"Média de faturamento diário...: {mediaDiariaDiario.ToString("C4")}");
            Console.WriteLine("");
            Console.WriteLine("Dia(s) com faturamento superior a Média Diária:");

            foreach (DTOJson dia in listaDiasComValorAcimaMediaMensal)
            {
                Console.WriteLine($"Dia {dia.Dia.ToString("00")} - Valor: {dia.Valor}");
            }

        }
        Console.ReadKey();
    }
}