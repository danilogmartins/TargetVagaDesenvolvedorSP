﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teste04
{
    public class FaturamentoUF
    {
        public string UF { get; set; }  
        public decimal ValorFaturamento { get; set; }
    }
}
