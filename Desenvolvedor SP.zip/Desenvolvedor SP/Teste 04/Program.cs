﻿using Teste04;

decimal valorFatTotal = 0;
List<FaturamentoUF> listaFaturamentoUF = new List<FaturamentoUF>
{
    new FaturamentoUF{ UF = "SP", ValorFaturamento = 67836.43m},
    new FaturamentoUF{ UF = "RJ" , ValorFaturamento = 36678.66m},
    new FaturamentoUF{ UF = "MG" , ValorFaturamento = 29229.88m},
    new FaturamentoUF{ UF = "ES" , ValorFaturamento = 27165.48m},
    new FaturamentoUF{ UF = "OUTROS" , ValorFaturamento = 19849.53m}
};

valorFatTotal = listaFaturamentoUF.Sum(x => x.ValorFaturamento);

foreach(FaturamentoUF uf in listaFaturamentoUF)
{
    Console.WriteLine($"UF: {uf.UF} - Valor Faturamento: {uf.ValorFaturamento.ToString("C2")} - Percentual Representação: {((uf.ValorFaturamento / valorFatTotal) * 100) .ToString("N2")}");
}
    
    
