

using System;
using System.Collections.Generic;
					
public class Program
{
	public static void Main()
	{	
        int _numero = 9; 
		bool _numExisteSequencia = false;
        List<int> listaFib = GerarFibonnaci(_numero);
		foreach(int num in listaFib)
		{
			Console.Write(string.Format("{0}, ", num));
		}		
		
		_numExisteSequencia = listaFib.Contains(_numero);
		
		if(_numExisteSequencia)
		{
			Console.WriteLine(string.Format("\n\nO NÚMERO {0} EXISTE NA SEQUÊNCIA GERADA.", _numero));
		}
		else			
		{
			Console.WriteLine(string.Format("\n\nO NÚMERO {0} NÃO EXISTE NA SEQUÊNCIA GERADA.", _numero));
		}
	}
	
	static List<int> GerarFibonnaci(int numero)
	{
		int _n1 = 0; 
		int _n2 = 1; 
		int _n3 = 0;
		List<int> lstRet = new List<int>{0,1};
		
		for(int i = 2; i < numero; ++i)
		{    
			_n3 = _n1 + _n2;    
			lstRet.Add(_n3);
			_n1 = _n2;    
			_n2 = _n3;    
        }    
		return lstRet;
	}
}